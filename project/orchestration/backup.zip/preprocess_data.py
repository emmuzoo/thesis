import os
import re
import click
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from nltk.corpus import stopwords
import nltk
import joblib
import pickle
from prefect import flow, task 

# Descargar stopwords si es necesario
nltk.download('stopwords')

def dump_pickle(obj, filename: str):
    with open(filename, "wb") as f_out:
        return pickle.dump(obj, f_out)


# Función para preprocesar el texto
def preprocess_text(text: str):
    text = text.lower()  # Convertir a minúsculas
    text = re.sub(r'[^a-z\s]', '', text)  # Eliminar caracteres extraños
    stop_words = set(stopwords.words('english'))
    text = ' '.join([word for word in text.split() if word not in stop_words])  # Eliminar stop words
    return text


# Función para preprocesar el dataset
@task(
    name="preprocess data", 
    tags=["data"], 
    retries=3, 
    retry_delay_seconds=60
)
def preprocess(df: pd.DataFrame, tfidf: TfidfVectorizer):
    #df = pd.read_csv(data_path)
    df = df[['review', 'sentiment']]
    label_encoder = LabelEncoder()
    df['sentiment'] = label_encoder.fit_transform(df['sentiment'])
    df['review'] = df['review'].apply(preprocess_text)

    X = df['review']
    y = df['sentiment']

    X_tfidf = tfidf.fit_transform(X)

    return X_tfidf, y


@click.command()
@click.option(
    '--raw_data_path', 
    type=click.Path(exists=True),
    help="Location where the raw idbm data was saved")
@click.option(
    '--dest_path', 
    type=click.Path(), 
    help="Location where the resulting files will be saved")
@click.option('--test_size', default=0.2, help='Proporción del conjunto de prueba')
@click.option('--val_size', default=0.1, help='Proporción del conjunto de validación')
def run_data_prep(raw_data_path: str, dest_path: str, test_size: float, val_size: float):
    # Load parquet files
    df_train = pd.read_csv(
        raw_data_path
    )

    # Fit the DictVectorizer and preprocess data
    max_features = 5000
    tfidfv = TfidfVectorizer(max_features=max_features)
    X, y = preprocess(df_train, tfidfv)

    X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=test_size, random_state=42)
    val_size_adjusted = val_size / (1 - test_size)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=val_size_adjusted, random_state=42)
    
    # Create dest_path folder unless it already exists
    os.makedirs(dest_path, exist_ok=True)

    # Save DictVectorizer and datasets
    #dump_pickle(tfidfv, os.path.join(dest_path, "tfidfv.pkl"))
    joblib.dump(tfidfv, os.path.join(dest_path, "tfidfv.pkl"))
    dump_pickle((X, y), os.path.join(dest_path, "clean_data.pkl"))
    dump_pickle((X_train, y_train), os.path.join(dest_path, "train.pkl"))
    dump_pickle((X_val, y_val), os.path.join(dest_path, "val.pkl"))
    dump_pickle((X_test, y_test), os.path.join(dest_path, "test.pkl"))

if __name__ == '__main__':
    run_data_prep()
