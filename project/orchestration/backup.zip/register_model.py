import os
import pickle
import click
import mlflow
import xgboost as xgb
from mlflow.models import infer_signature
from mlflow.entities import ViewType
from mlflow.tracking import MlflowClient
from sklearn.metrics import accuracy_score, recall_score


HPO_EXPERIMENT_NAME = "setana-xgboost-hyperopt"
EXPERIMENT_NAME = "sentana-xgboost-best-models"
RF_PARAMS = ['max_depth', 'n_estimators', 'min_samples_split', 'min_samples_leaf', 'random_state']

mlflow.set_tracking_uri("http://127.0.0.1:5000")
mlflow.set_experiment(EXPERIMENT_NAME)
mlflow.sklearn.autolog()


def load_pickle(filename):
    with open(filename, "rb") as f_in:
        return pickle.load(f_in)


def train_and_log_model(data_path, params):
    X_train, y_train = load_pickle(os.path.join(data_path, "train.pkl"))
    X_val,   y_val   = load_pickle(os.path.join(data_path, "val.pkl"))
    X_test,  y_test  = load_pickle(os.path.join(data_path, "test.pkl"))

    print(params)
    with mlflow.start_run():
        #for param in RF_PARAMS:
        #    params[param] = int(params[param])
        
        dtrain = xgb.DMatrix(X_train, label=y_train)
        dvalid = xgb.DMatrix(X_val, label=y_val)
        dtest  = xgb.DMatrix(X_test, label=y_test)
        evals = [(dtrain, 'train'), (dvalid, 'eval')]
        bst = xgb.train(params, dtrain, evals=evals, num_boost_round=100, early_stopping_rounds=10, verbose_eval=False)

        # Evaluate val
        y_pred_val = bst.predict(dvalid)
        y_pred_val_labels = (y_pred_val > 0.5).astype(int)
        val_accuracy = accuracy_score(y_val, y_pred_val_labels)
        val_recall = recall_score(y_val, y_pred_val_labels)

        # Evaluate test
        y_pred_test = bst.predict(dtest)
        y_pred_test_labels = (y_pred_test > 0.5).astype(int)
        test_accuracy = accuracy_score(y_test, y_pred_test_labels)
        test_recall = recall_score(y_test, y_pred_test_labels)

        # Log to MLflow
        signature = infer_signature(X_train, y_pred_val)
        mlflow.xgboost.log_model(bst, "model", signature=signature)
        mlflow.log_params(params)
        mlflow.log_metric("logloss", bst.best_score)
        mlflow.log_metric("val_accuracy", val_accuracy)
        mlflow.log_metric("val_recall", val_recall)
        mlflow.log_metric("test_accuracy", test_accuracy)
        mlflow.log_metric("test_recall", test_recall)


@click.command()
@click.option(
    "--data_path",
    default="./output",
    help="Location where the processed NYC taxi trip data was saved"
)
@click.option(
    "--top_n",
    default=5,
    type=int,
    help="Number of top models that need to be evaluated to decide which one to promote"
)
def run_register_model(data_path: str, top_n: int):

    client = MlflowClient()

    # Retrieve the top_n model runs and log the models
    experiment = client.get_experiment_by_name(HPO_EXPERIMENT_NAME)
    runs = client.search_runs(
        experiment_ids=experiment.experiment_id,
        run_view_type=ViewType.ACTIVE_ONLY,
        max_results=top_n,
        order_by=["metrics.accuracy ASC"]
    )
    for run in runs:
        train_and_log_model(data_path=data_path, params=run.data.params)

    # Select the model with the lowest test RMSE
    experiment = client.get_experiment_by_name(EXPERIMENT_NAME)
    # best_run = client.search_runs( ...  )[0]
    best_run = client.search_runs(
        experiment_ids=experiment.experiment_id,
        run_view_type=ViewType.ACTIVE_ONLY,
        max_results=top_n,
        order_by=["metrics.test_accuracy ASC"]
    )[0]
    
    # Register the best model
    # mlflow.register_model( ... )
    mlflow.register_model(
        model_uri=f"runs:/{best_run.info.run_id}/model",
        name="xgboost-model"
    )


if __name__ == '__main__':
    run_register_model()
