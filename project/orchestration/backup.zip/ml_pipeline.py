import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from prefect import flow, task
from preprocess_data import preprocess
from split import split_data
from prefect.task_runners import SequentialTaskRunner

@task(
    name="read data", 
    tags=["data"], 
    retries=3, 
    retry_delay_seconds=60
)
def read_data(filename='Womens Clothing E-Commerce Reviews.csv'):
    data = pd.read_csv(filename)
    print("Data loaded.\n\n")
    return data


@flow(
    name="Sentiment-Analysis-Flow",
    description="A flow to run the pipeline for the customer sentiment analysis",
    task_runner=SequentialTaskRunner()
)
def run_worflow():

    # Load data
    raw_dataset_path = "/workspaces/mlops-zoomcamp/project/raw/IMDB Dataset.csv"
    df = read_data(raw_dataset_path)

    # Preprocessing
    max_features = 5000
    tfidfv = TfidfVectorizer(max_features=max_features)
    X, y = preprocess(df, tfidfv)

    # Split data
    



if __name__ == '__main__':
    run_worflow()


    #kaggle datasets download -d lakshmi25npathi/imdb-dataset-of-50k-movie-reviews